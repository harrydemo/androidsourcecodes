package zyf.test.ProgressBar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class AppWidget extends AppWidgetProvider {
	private static AppWidgetManager appManager;
	private static RemoteViews views;
	private static ComponentName thisWidget;
	private static int Tag=0;
	@Override
	public void onEnabled(Context context) {
		// TODO Auto-generated method stub
		super.onEnabled(context);
		
		appManager=AppWidgetManager.getInstance(context);
		views = new RemoteViews(context.getPackageName(),R.layout.widgetlayout);
		thisWidget = new ComponentName(context, AppWidget.class);

	}

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		super.onReceive(context, intent);
		if(intent.getAction().equals("zyf.test.widget.UP")){
			Tag+=5;
			if(Tag>100){
				Tag=100;
			}
			views.setProgressBar(R.id.widget_ProgressBar, 100, Tag, false);
			appManager.updateAppWidget(thisWidget, views);
		}
		if(intent.getAction().equals("zyf.test.widget.DOWN")){
			Tag-=5;
			if(Tag<0){
				Tag=0;
			}
			views.setProgressBar(R.id.widget_ProgressBar, 100, Tag, false);
			appManager.updateAppWidget(thisWidget, views);
		}
	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		// TODO Auto-generated method stub
		final int N = appWidgetIds.length;

		// Perform this loop procedure for each App Widget that belongs to this provider
		for (int i=0; i<N; i++) {
			int appWidgetId = appWidgetIds[i];
			RemoteViews views=new RemoteViews(context.getPackageName(), R.layout.widgetlayout);
			
			Intent UPintent=new Intent("zyf.test.widget.UP");
			Intent DOWNintent=new Intent("zyf.test.widget.DOWN");
			PendingIntent pendingIntentUp=PendingIntent.getBroadcast(context, 0, UPintent, 0);
			PendingIntent pendingIntentDown=PendingIntent.getBroadcast(context, 0, DOWNintent, 0);
			views.setOnClickPendingIntent(R.id.widget_BT_Up, pendingIntentUp);
			views.setOnClickPendingIntent(R.id.widget_BT_Down, pendingIntentDown);
			
			appWidgetManager.updateAppWidget(appWidgetId, views);
		}
	}
}
