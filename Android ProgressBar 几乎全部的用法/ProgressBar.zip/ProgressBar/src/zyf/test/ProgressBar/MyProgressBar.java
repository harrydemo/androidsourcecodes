package zyf.test.ProgressBar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MyProgressBar extends Activity implements OnClickListener, android.content.DialogInterface.OnClickListener {
	/** Called when the activity is first created. */
	private Button up1, down1;
	private Button up2, down2;
	private Button roundA, roundB, rectA, rectB;
	private ProgressBar myProgressBar;
	private AlertDialog.Builder AlterD,AlterD2;
	private LayoutInflater layoutInflater;
	private LinearLayout myLayout;
	private Button myup,mydown;
	private ProgressBar mypro;
	private LayoutInflater layoutInflater2;
	private LinearLayout myLayout2;
	private static final int Round_A=110;
	private static final int Round_B=120;
	private static final int Rect_A=130;
	private static final int Rect_B=140;
	private static int Tag=0;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SetFeature();
		FindView();
		SetListener();
		setProgress(myProgressBar.getProgress() * 100);
		setSecondaryProgress(myProgressBar.getSecondaryProgress() * 100);
	
	}

	private void SetFeature() {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_PROGRESS);
		// requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.main);
		setProgressBarVisibility(true);

	}

	private void SetListener() {
		// TODO Auto-generated method stub
		up1.setOnClickListener(this);
		down1.setOnClickListener(this);
		up2.setOnClickListener(this);
		down2.setOnClickListener(this);
		roundA.setOnClickListener(this);
		roundB.setOnClickListener(this);
		rectA.setOnClickListener(this);
		rectB.setOnClickListener(this);

	}

	private void FindView() {
		// TODO Auto-generated method stub
		up1 = (Button) findViewById(R.id.bt1_Up);
		down1 = (Button) findViewById(R.id.bt1_Down);
		up2 = (Button) findViewById(R.id.bt2_Up);
		down2 = (Button) findViewById(R.id.bt2_Down);
		myProgressBar = (ProgressBar) findViewById(R.id.progressbar_updown);
		roundA = (Button) findViewById(R.id.bt_RoundA);
		roundB = (Button) findViewById(R.id.bt_RoundB);
		rectA = (Button) findViewById(R.id.bt_RectA);
		rectB = (Button) findViewById(R.id.bt_RectB);
		AlterD=new AlertDialog.Builder(this);
		AlterD2=new AlertDialog.Builder(this);

	}

	@Override
	public void onClick(View button) {
		// TODO Auto-generated method stub
		SwitchUPorDown(button);
		setProgress(myProgressBar.getProgress() * 100);
		setSecondaryProgress(myProgressBar.getSecondaryProgress() * 100);
	}

	private void SwitchUPorDown(View button) {
		switch (button.getId()) {
		case R.id.bt1_Up: {
			myProgressBar.incrementProgressBy(5);
		}
			break;
		case R.id.bt1_Down: {
			myProgressBar.incrementProgressBy(-5);
		}
			break;
		case R.id.bt2_Up: {
			myProgressBar.incrementSecondaryProgressBy(5);
		}
			break;
		case R.id.bt2_Down: {
			myProgressBar.incrementSecondaryProgressBy(-5);
		}
		case R.id.bt_RoundA: {
			showDialog(Round_A);
		}
		case R.id.bt_RoundB: {
			showDialog(Round_B);
		}
		case R.id.bt_RectA: {
			showDialog(Rect_A);
		}
		case R.id.bt_RectB: {
			showDialog(Rect_B);
		}
			break;
		case R.id.myView_BT_Up: {
			mypro.incrementProgressBy(1);
			
		}
			break;
		case R.id.myView_BT_Down: {
			mypro.incrementProgressBy(-1);
		}
			break;
		default:
			break;
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		// TODO Auto-generated method stub
		switch (id) {
		case Round_A:{
			ProgressDialog mypDialog=new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mypDialog.setTitle("Android");
			mypDialog.setMessage(getResources().getString(R.string.first));
			mypDialog.setIcon(R.drawable.android);
			mypDialog.setIndeterminate(false);
			mypDialog.setCancelable(true);
			return mypDialog;
		}
		case Round_B:{
			ProgressDialog mypDialog=new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mypDialog.setTitle("Google");
			mypDialog.setMessage(getResources().getString(R.string.second));
			mypDialog.setIcon(R.drawable.android);
			mypDialog.setButton("Google",this);
			mypDialog.setIndeterminate(false);
			mypDialog.setCancelable(true);
			return mypDialog;
		}

		case Rect_A:{
			ProgressDialog mypDialog=new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			mypDialog.setTitle(getResources().getString(R.string.me));
			mypDialog.setMessage(getResources().getString(R.string.third));
			mypDialog.setIcon(R.drawable.android);
			mypDialog.setProgress(59);
			mypDialog.setIndeterminate(true);
			mypDialog.setCancelable(true);
			return mypDialog;
		}

		case Rect_B:{
			ProgressDialog mypDialog=new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			mypDialog.setTitle(getResources().getString(R.string.HellSun));
			mypDialog.setMessage(getResources().getString(R.string.fourth));
			mypDialog.setIcon(R.drawable.android);
			mypDialog.setProgress(59);
			mypDialog.setButton(getResources().getString(R.string.HellSun),this);
			mypDialog.setIndeterminate(true);
			mypDialog.setCancelable(true);
			return mypDialog;
		}
		}
		return null;
	}

	@SuppressWarnings("static-access")
	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		if(which==dialog.BUTTON1){
			Toast.makeText(this, "Button1",Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0, 1, 1, "Round").setIcon(R.drawable.ma);
		menu.add(0, 2, 2, "Rect").setIcon(R.drawable.mb);;
		menu.add(0, 3, 3, "Title").setIcon(R.drawable.mc);
		return super.onCreateOptionsMenu(menu);
	}

	@SuppressWarnings("static-access")
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case 1:{
			layoutInflater2=(LayoutInflater) getSystemService(this.LAYOUT_INFLATER_SERVICE);
			myLayout2=(LinearLayout) layoutInflater2.inflate(R.layout.roundprogress, null);
			AlterD2.setTitle(getResources().getString(R.string.RoundO));
			AlterD2.setIcon(R.drawable.ma);
			AlterD2.setMessage(getResources().getString(R.string.ADDView));
			AlterD2.setView(myLayout2);
			AlterD2.show();
		}
			break;
		case 2:{
			layoutInflater=(LayoutInflater) getSystemService(this.LAYOUT_INFLATER_SERVICE);
			myLayout=(LinearLayout) layoutInflater.inflate(R.layout.myview, null);
			myup=(Button) myLayout.findViewById(R.id.myView_BT_Up);
			mydown=(Button) myLayout.findViewById(R.id.myView_BT_Down);
			mypro=(ProgressBar)myLayout.findViewById(R.id.myView_ProgressBar);
			myup.setOnClickListener(this);
			mydown.setOnClickListener(this);
			mypro.setProgress(Tag);
			AlterD.setTitle(getResources().getString(R.string.RectO));
			AlterD.setIcon(R.drawable.mb);
			AlterD.setMessage(getResources().getString(R.string.ADDView));
			AlterD.setView(myLayout);
			AlterD.setPositiveButton("OK", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					MyProgressBar.Tag=mypro.getProgress();
				}});
			AlterD.show();
		}
			break;
		case 3:{
			Intent startIntent=new Intent();
			startIntent.setClass(MyProgressBar.this, MyActivity.class);
			startActivity(startIntent);
		}
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
}