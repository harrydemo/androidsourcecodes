package com.teleca.jamendo.gestures;

public interface GestureCommand {

	void execute();
}
