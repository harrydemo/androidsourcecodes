package com.teleca.jamendo.util;

public enum SeekToMode {
	ERewind, EForward

}
