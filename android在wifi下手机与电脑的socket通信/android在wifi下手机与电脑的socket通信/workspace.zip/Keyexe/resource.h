//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Keyexe.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_KEYEXE_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_NOTIFY               133
#define IDI_ICON_BIRD                   134
#define IDC_BUTTON_START                1000
#define IDC_STATIC_IP                   1003
#define IDC_BUTTON_NOTIFY               1004
#define IDC_STATIC_KEY                  1006
#define IDC_EDIT_IP                     1007
#define IDC_BUTTON_CONNECT              1008
#define IDC_BUTTON_SEND                 1009
#define IDC_EDIT_SEND                   1010
#define IDC_BUTTON_SERVER               1011
#define IDC_EDIT_SERVER                 1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
